package com.ckcrabbitmq.consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRabbitmqConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
