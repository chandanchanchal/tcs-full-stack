package com.ckc.springbootrabbitmqproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
