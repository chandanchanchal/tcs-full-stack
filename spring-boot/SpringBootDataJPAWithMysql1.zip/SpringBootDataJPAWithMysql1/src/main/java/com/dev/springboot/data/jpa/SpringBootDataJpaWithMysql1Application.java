package com.dev.springboot.data.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDataJpaWithMysql1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDataJpaWithMysql1Application.class, args);
	}

}
