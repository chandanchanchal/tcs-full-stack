package com.erwan.human.exceptions;

public class BeanNotFound extends Exception {

    public BeanNotFound(String message) {
        super(message);
    }
}
