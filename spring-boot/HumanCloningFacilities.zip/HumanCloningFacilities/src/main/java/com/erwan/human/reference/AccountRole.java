package com.erwan.human.reference;

public enum AccountRole {
    KAMINOAIN, EMPEROR
}
