package com.erwan.human.dao;

import com.erwan.human.domaine.Clone;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CloneRepository extends JpaRepository<Clone, Long>{
}
