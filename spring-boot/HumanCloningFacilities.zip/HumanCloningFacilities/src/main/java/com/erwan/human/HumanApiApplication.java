package com.erwan.human;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HumanApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(HumanApiApplication.class, args);
    }

}
