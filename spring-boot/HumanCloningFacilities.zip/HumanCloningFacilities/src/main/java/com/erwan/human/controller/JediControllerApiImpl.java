package com.erwan.human.controller;

import org.openapitools.client.api.JediControllerApi;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JediControllerApiImpl extends JediControllerApi {
}
