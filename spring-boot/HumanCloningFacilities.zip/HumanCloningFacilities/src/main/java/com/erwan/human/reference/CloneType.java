package com.erwan.human.reference;

public enum CloneType {

    flametrooper, medic, gunner, scoot, jetpack;
}
